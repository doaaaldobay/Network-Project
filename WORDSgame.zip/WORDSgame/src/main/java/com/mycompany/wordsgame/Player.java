/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wordsgame;

import java.util.ArrayList;

/**
 *
 * @author pc
 */
public class Player {
    
    public String name ;
    public int points ;
    
    public Player() {

    }
    
    public Player(String playerName) {
        name = playerName ;
        points = 0 ;
    }
}