/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wordsgame;

/**
 *
 * @author pc
 */
import java.io.*; 
import java.net.*; 
import java.util.ArrayList;
  
// Server class 
public class Server { 
    
    public static ArrayList<String> playersList = new ArrayList<>();
    
    public static void AddPlayer(String name) {
        playersList.add(name) ;
    }
    
    public static void main(String[] args) {        
        startServer() ;
    } 
    ////////////////////////////////////////////////////////////////////////////
    public static void startServer() {
    ServerSocket server = null;

    try {
        server = new ServerSocket(1234);
        server.setReuseAddress(true);
        System.out.println("SERVER STARTED");
        // Running infinite loop for getting client request
        while (true) {
            Socket client = server.accept();

            // create a new thread object
            ClientHandler clientSock = new ClientHandler(client);

            // This thread will handle the client separately
            new Thread(clientSock).start();
        }
    } catch (IOException e) {
        e.printStackTrace();
    } finally {
        if (server != null) {
            try {
                server.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
    ////////////////////////////////////////////////////////////////////////////
    // ClientHandler class that will handle multiple clients
    private static class ClientHandler implements Runnable { 
        private final Socket clientSocket; 
  
        // Constructor 
        public ClientHandler(Socket socket) 
        { 
            this.clientSocket = socket; 
        } 
  
        @Override
        public void run() 
        { 
            PrintWriter out = null; 
            BufferedReader in = null; 
            try {
                    
                  // get the outputstream and inputstream of client 
                out = new PrintWriter(clientSocket.getOutputStream(), true); 
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); 
  
                String username;
                username = in.readLine() ;
                
                System.out.println("Received username from client: " + username) ;
                
                playersList.add(username) ;
                System.out.println("Updated players list: " + playersList);

                String playersListString = String.join(",", playersList);

                // Send the player list back to the client
                out.println(playersListString);
                out.flush();
            }
            catch (IOException e) { 
                e.printStackTrace(); 
            } 
            finally { 
                try { 
                    if (out != null) { 
                        out.close(); 
                    } 
                    if (in != null) { 
                        in.close(); 
                        clientSocket.close(); 
                    } 
                } 
                catch (IOException e) { 
                    e.printStackTrace(); 
                } 
            } 
        } 
    } 
}
